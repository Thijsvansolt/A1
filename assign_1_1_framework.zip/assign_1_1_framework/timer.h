/*
 * timer.h
 */

#pragma once

void timer_start(void);
double timer_end(void);
